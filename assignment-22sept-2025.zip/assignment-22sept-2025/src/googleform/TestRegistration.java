package googleform;

public class TestRegistration {


	public static void main(String[] args) {
		RegistrationForm veda=new RegistrationForm();

	}

}
